#!usr/bin/env python
# coding=utf-8

"""
@company:广东浩迪创新科技有限公司
@version: ??
@author: linwl
@file: conversiontool.py
@time: 2018/3/1 15:57
@function：转换工具类
"""

from collections import defaultdict
import array


def dedupe_list(items):
    seen = set()
    for item in items:
        if item not in seen:
            yield item
            seen.add(item)

def dedupe_dict(items, key=None):
    '''
    移除元素为字典重复项
    :param items:
    :param key:移除索引匿名函数
    :return:
    '''
    seen = set()
    for item in items:
        val = item if key is None else key(item)
        if val not in seen:
            yield item
            seen.add(val)

def dedupe_dict_repeat(items, key=None):
    '''
    获取元素为字典值重复项
    :param items:
    :param key:
    :return:
    '''
    seen = set()
    for item in items:
        val = item if key is None else key(item)
        if val in seen:
            yield item
        else:
            seen.add(val)

def group_by_element(lst):
    '''
    按重复值分组
    '''
    index = []
    for i, _ in enumerate(lst):
        if i < len(lst) - 1 and lst[i + 1] != lst[i]:
            index.append(i + 1)

    def take(lst, n):
        for i in range(n):
            yield next(lst)

    if not hasattr(lst, 'next'):
        lst = iter(lst)

    begin = 0
    for item in index:
        x = list(take(lst, item - begin ))
        begin = item
        yield x

    yield list(lst)

def hexstr_to_bytearray(hexstr,reverse = False):
    """
    十六进制字符串转换成Byte数组
    :param str:十六进制字符串
    :param reverse: False 低字节在前 True 高字节在前
    :return:
    """
    try:
        hexstr = hexstr.replace(' ','')
        if len(hexstr) % 2 ==1:
            hexstr = hexstr.strip().rjust(len(hexstr)+1, '0')
        bufferlength = len(hexstr) / 2
        buf = array.array('B')
        append = buf.append
        for i in range(bufferlength):
            bufstr = hexstr[i*2:i*2+2]
            bufint = int(bufstr, 16)
            append(bufint)
        if reverse:
            buf.reverse()
        return buf
    except Exception as e:
        raise RuntimeError(e)

def conver_uint64(byte_array,startIndex = 0):
    '''
    字节数组转64位无符整数
    :param bytearray:
    :return:
    '''
    try:
        temp = ''
        for i in range(startIndex,8):
            hex_str= hex(byte_array[i])[2:]
            temp  = temp + hex_str.rjust(2,"0")
        return int(temp,16)
    except Exception as e:
        raise RuntimeError(e)

def conver_bytes(uint64,reverse=False):
    '''
    长整型数字转字节数组
    :param uint64:
    :param reverse:False 低字节在前 True 高字节在前
    :return:
    '''
    try:
        hex_str = hex(uint64)[2:]
        buf = array.array('B')
        bufferlength = len(hex_str) / 2
        append = buf.append
        for i in range(bufferlength):
            data = int(hex_str[i*2:i*2+2],16)
            append(data)
        if 8 - len(buf) >0:
            repair_num = 8 - len(buf)
            for i in range(repair_num):
                append(0)
        if reverse:
            buf.reverse()
        return buf
    except Exception as e:
        raise RuntimeError(e)

def hexstr_to_strarray(hex_str,reverse = False):
    '''
    十六进制字符串转换成字符数组
    :param hex_str: 十六进制字符串
    :param reverse: False 低字节在前 True 高字节在前
    :return:
    '''
    try:
        hex_str = hex_str.replace(' ', '')
        if len(hex_str) % 2 == 1:
            hex_str = hex_str.strip().rjust(len(hex_str) + 1, '0')
        bufferlength = len(hex_str) / 2
        buf = []
        append = buf.append
        for i in range(bufferlength):
            bufstr = hex_str[i * 2:i * 2 + 2]
            append(bufstr)
        if reverse:
            buf.reverse()
        return buf
    except Exception as e:
        raise RuntimeError(e)