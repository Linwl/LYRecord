#!usr/bin/env python
# coding=utf-8

"""
@company:广东浩迪创新科技有限公司
@version: ??
@author: linwl
@file: threadTools.py
@time: 2018/12/3 15:20
@function：线程工具类
"""
from threading import Thread,currentThread
from datetime import datetime
import sys,traceback

class CustomThread(Thread):
    """
    自定义线程模块
    :param _erCode:0正常代码 1退出代码 2异常代码
    """
    _erCode =0#正常代码

    def __init__(self, *arg,**kwargs):
        super(CustomThread, self).__init__()  # 重写父类属性
        threadName = kwargs.get('threadName',None)
        if threadName:
            self.name = threadName
        self.args = kwargs.get('callable')
        self._callable = kwargs.get('callable',())
        self._exQueue = kwargs.get('exQueue')

    def getresult(self):
        return self._result

    def _run(self):
        start_msg = 'The Thread<{0}> start in {1}!'.format(self.name,datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        self._exQueue.put((self._erCode,start_msg))
        if isinstance(self.args, list):
            self._result = self._callable(*self.args)
        elif isinstance(self.args, dict):
            self._result = self._callable(**self.args)
        else:
            self._result = self._callable()
        end_msg = 'The Thread<{0}> exist in {1}!'.format(self.name,datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        self._erCode =1
        self._exQueue.put((self._erCode,end_msg))

    def run(self):
        try:
            self._run()
        except Exception as e:
            self._erCode = 2
            exc_info = ''.join(traceback.format_exception(*sys.exc_info()))
            exstr = '线程<{0}>发生异常:{1}'.format(self.name, exc_info)
            self._exQueue.put((self._erCode, exstr))
