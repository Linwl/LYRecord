#!usr/bin/env python
# coding=utf-8

"""
@company:广东浩迪创新科技有限公司
@version: ??
@author: linwl
@file: redismangeTools.py
@time: 2018/12/10 10:48
@function：
"""

import redis
from .configmange import ConfigMange
from datetime import timedelta
import threading

class RedisMange(object):
    # 模块版本号
    _Version = "1.0.2018.12.10"

    _instance_lock = threading.Lock()

    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, "_instance"):
            with cls._instance_lock:
                cls._instance = object.__new__(cls)
                cls._instance.initialize(*args, **kwargs)
        return cls._instance

    def __str__(self):
        return '(RedisMange:Redis缓存管理模块)'



    def initialize(self, path):
        '''
        只初始化一次配置
        :param path: redis连接配置文件路径
        '''
        self.init_redis(path)

    def init_redis(self, path):
        try:
            config = ConfigMange(path)
            host,port,db =config.get_redisconfig('Redis')
            self.re = redis.Redis(host=host, port=port, db=db)
        except Exception as e:
            raise e

    # 初始化函数
    def __init__(self, path):
        if self.re is None:
            self.init_redis(path)
        else:
            pass

    def set_redis(self, Key, Value, Interval = None,Format = "S"):
        '''
        单条设置redis缓存
        :param Key:
        :param Value:
        :param Interval: 过期间隔
        :param Format: 间隔格式 D:天数 H:小时 M:分钟S:秒
        :return:
        '''
        try:
            if Interval:
                if Format =='S':
                    self.re.set(Key, Value, ex=Interval)
                elif Format =='M':
                    Interval = timedelta(minutes=Interval)
                    self.re.set(Key, Value, ex=Interval)
                elif Format == 'H':
                    Interval = timedelta(hours=Interval)
                    self.re.set(Key, Value, ex=Interval)
                elif Format == 'D':
                    Interval = timedelta(days=Interval)
                    self.re.set(Key, Value, ex=Interval)
            else:
                self.re.set(Key, Value)
        except Exception as e:
            raise RuntimeError(e)


    def get_redis(self, Key):
        '''
        #根据Key获取单条缓存
        :param Key:
        :return:
        '''
        try:
            return self.re.get(Key)
        except Exception as e:
            raise RuntimeError(e)

    def get_dbsiza(self):
        '''
         #获取redis缓存的记录数量
        :return:
        '''
        try:
            return self.re.dbsize()
        except Exception as e:
            raise RuntimeError(e)

    def mset_redis(self, dic):
        '''
        # 批量设置redis缓存
        :param dic:数据字典
        :return:
        '''
        try:
            self.re.mset(dic)
        except Exception as ex:
            raise ex


    def mget_redis(self, keys):
        '''
        根据key列表获取缓存数据
        :param keys:缓存key列表
        :return:
        '''
        try:
            return self.re.mget(keys)
        except Exception as ex:
            raise ex

    def set_lpush(self, lstName, *values):
        '''
        #利用list设置redis缓存
        :param lstName:
        :param values:
        :return:
        '''
        try:
            return self.re.lpush(lstName, values)
        except Exception as ex:
            raise ex

    # 分段获取列表值
    def get_lrange(self, lstName, stratIndex, endIndex):
        try:
            return self.re.lrange(lstName, stratIndex, endIndex)
        except Exception as ex:
            raise ex

    def clear(self):
        '''
        清空缓存
        :return:
        '''
        try:
            return self.re.flushdb()
        except Exception as ex:
            raise ex

    def remove(self, keys):
        '''
        删除指定key列表的缓存
        :param key:
        :return:
        '''
        try:
            names = []
            if isinstance(keys,str):
                names.append(keys)
            elif isinstance(keys,list):
                names.extend(keys)
            else:
                raise TypeError('输入类型错误!')
            return self.re.delete(*names)
        except Exception as ex:
            raise RuntimeError(ex)

    def get_keys(self):
        try:
            return self.re.keys()
        except Exception as e:
            raise RuntimeError(e)