#!usr/bin/env python
# coding=utf-8

"""
@company:广东浩迪创新科技有限公司
@version: ??
@author: linwl
@file: performanceTools.py
@time: 2018/10/26 10:06
@function：
"""

from functools import wraps
from datetime import datetime

def cal_time(func):
    """
    统计方法耗时装饰器
    :param func:
    :return:
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        self = args[0]
        try:
            t1 = datetime.now()
            result = func(*args, **kwargs)
            t2 = datetime.now()
            self.log.info("{0} running time:{1}秒!".format(func.__name__, (t2 - t1)))
        except Exception as e:
            self.log.error('统计方法耗时装饰器发生异常:{0}'.format(e))
        finally:
            return result
    return wrapper