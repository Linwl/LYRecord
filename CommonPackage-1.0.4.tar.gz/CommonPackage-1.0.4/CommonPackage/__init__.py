#!usr/bin/env python
# coding=utf-8

"""
@company:广东浩迪创新科技有限公司
@version: ??
@author: linwl
@file: __init__.py.py
@time: 2018/12/3 11:28
@function：
"""
__Version__ ='1.0.1'