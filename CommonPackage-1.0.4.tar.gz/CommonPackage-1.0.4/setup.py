#!usr/bin/env python
# coding=utf-8

"""
@company:广东浩迪创新科技有限公司
@version: ??
@author: linwl
@file: setup.py.py
@time: 2018/12/3 11:55
@function：通用包脚本
"""

__author__ = 'Linwl'

from setuptools import setup

setup(
    name="CommonPackage",
    version="1.0.4",
    author="Linwl",
    author_email="304115325@qq.com",
    description="数据分析基础通用包",
    keywords="dictionary",
    packages=['CommonPackage',
              'CommonPackage/Tools',
              ],
    # test_suite="nxdictionary.test",  # 指定测试包位置， python setup.py test
    dependency_links=[],  # 添加依赖链接
    install_requires=[
        'pyDes >= 2.0.1',
        'requests >= 2.19.1',
        'pymongo>=3.7.1',
        'redis >=3.0.1'
    ]
)